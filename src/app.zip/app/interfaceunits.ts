export interface InterfaceUnits{
  [x: string]: any;
  id: number;
  name: string;
  building_id: number;
  user_id: number; 
  phone: string;
  email: string;
  accessTokens: any[];
}
