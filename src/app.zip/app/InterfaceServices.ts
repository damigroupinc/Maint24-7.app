export interface InterfaceServices{
  id: number;
  name: string;
}
