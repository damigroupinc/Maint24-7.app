export interface InterfaceHistory {
  id: number;
  serviceorder_id: number;
  description: string;
  image: string;
}
