export interface InterfaceBuildings{
  [x: string]: any;
  id: number;
  name: string;
  accessTokens: any[];
}
